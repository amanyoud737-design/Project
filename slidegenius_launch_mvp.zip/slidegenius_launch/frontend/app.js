/* SlideGenius Launch (MVP)
   - Admin is protected by backend session (/admin)
   - PayPal Client ID loaded from /config.js (ENV)
   - Templates are stored in localStorage (MVP) — later we move to DB
*/

const CONFIG = window.__SG_CONFIG__ || {};
const PAYPAL_CLIENT_ID = CONFIG.PAYPAL_CLIENT_ID || "";
const CURRENCY = "USD";

function calcPriceUSD(templatePrice, slidesCount){
  const base = Number(templatePrice || 0);
  const slides = Number(slidesCount || 0);
  const extra = slides > 10 ? (slides - 10) * 0.25 : 0;
  return Math.max(1, +(base + extra).toFixed(2));
}

const $ = (id) => document.getElementById(id);

const state = {
  lang: "ar",
  boxEditMode: false,
  templates: [],
  isAdmin: false,
  editor: {
    templateId: "",
    title: "",
    body: "",
    font: "Cairo",
    fontSize: 16,
    color: "#13b6ec",
    slides: 10,
    userImageDataUrl: ""
  },
  adminDraft: {
    bgDataUrl: "",
    titleBox: { x: 8, y: 12, w: 55, h: 18 },
    bodyBox:  { x: 8, y: 34, w: 55, h: 50 },
    imageBox: { x: 67,y: 12, w: 28, h: 72 }
  }
};

const T = {
  ar: {
    brandSub:"منصّة عروض",
    navHome:"الرئيسية", navTemplates:"القوالب", navEditor:"المحرر", navPricing:"الأسعار", navAdmin:"الأدمن",
    heroTitle:"حوّل أفكارك لعرض احترافي خلال ثواني",
    heroSub:"اختاري قالب، اكتبي المحتوى، ارفعي صورتك، وجربي الدفع.",
    tplTitle:"القوالب", tplSub:"اختاري قالب وابدئي تعديل المحتوى.",
    edTitle:"المحرر", edSub:"اختاري قالب + اكتبي العنوان والنص + ارفعي صورتك.",
    settingsTitle:"إعدادات العرض",
    lblTemplate:"القالب",
    lblTopic:"العنوان",
    lblBody:"النص",
    lblFont:"الخط",
    lblFontSize:"حجم الخط",
    lblColor:"اللون الأساسي",
    lblSlides:"عدد الشرائح",
    lblUserImage:"صورة المستخدم",
    previewTitle:"المعاينة",
    previewHint:"* الأدمن يحدد أماكن الصناديق. أنتِ تكتبين المحتوى فقط.",
    ckTitle:"الدفع",
    ckSub:"PayPal — إذا الزر ما ظهر، تأكدي Client ID.",
    orderTitle:"تفاصيل الطلب",
    ppBoxTitle:"PayPal",
    ppNote:"Sandbox: استخدمي حساب Buyer التجريبي.",
    adTitle:"لوحة الأدمن",
    adSub:"ارفعي صورة قالب وحددي أماكن Title/Body/Image بالسحب.",
    tplAddTitle:"إضافة قالب جديد",
    lblTplName:"اسم القالب",
    lblTplPrice:"السعر الأساسي (USD)",
    lblTplMax:"أقصى عدد شرائح",
    lblTplBg:"صورة القالب (خلفية)",
    tplListTitle:"قائمة القوالب",
    adminPreviewTitle:"معاينة الأدمن (تحريك الصناديق)",
    prTitle:"الأسعار",
    prSub:"السعر = سعر القالب + زيادة بسيطة بعد 10 شرائح."
  },
  en: {
    brandSub:"AI Presentations",
    navHome:"Home", navTemplates:"Templates", navEditor:"Editor", navPricing:"Pricing", navAdmin:"Admin",
    heroTitle:"Turn ideas into a pro deck in seconds",
    heroSub:"Pick a template, write content, upload an image, and checkout.",
    tplTitle:"Templates", tplSub:"Pick a template and start editing.",
    edTitle:"Editor", edSub:"Pick a template + write title/body + upload your image.",
    settingsTitle:"Deck Settings",
    lblTemplate:"Template",
    lblTopic:"Title",
    lblBody:"Body",
    lblFont:"Font",
    lblFontSize:"Font Size",
    lblColor:"Theme Color",
    lblSlides:"Slides",
    lblUserImage:"User Image",
    previewTitle:"Preview",
    previewHint:"* Admin defines boxes; users only edit content.",
    ckTitle:"Checkout",
    ckSub:"PayPal — if the button is missing, check Client ID.",
    orderTitle:"Order Details",
    ppBoxTitle:"PayPal",
    ppNote:"Sandbox: login using a Sandbox Buyer account.",
    adTitle:"Admin Panel",
    adSub:"Upload background and drag Title/Body/Image boxes.",
    tplAddTitle:"Add New Template",
    lblTplName:"Template Name",
    lblTplPrice:"Base Price (USD)",
    lblTplMax:"Max Slides",
    lblTplBg:"Template Background",
    tplListTitle:"Templates List",
    adminPreviewTitle:"Admin Preview (drag boxes)",
    prTitle:"Pricing",
    prSub:"Price = template base + small extra after 10 slides."
  }
};

const fonts = [
  { key:"Cairo", ar:"كايرو (مصري حديث)", en:"Cairo" },
  { key:"Aref Ruqaa", ar:"رقعة (Aref Ruqaa)", en:"Ruqaa" },
  { key:"Noto Naskh Arabic", ar:"نسخ (Noto Naskh)", en:"Naskh" },
  { key:"Noto Kufi Arabic", ar:"كوفي (Noto Kufi)", en:"Kufi" },
  { key:"Reem Kufi", ar:"كوفي ناعم (Reem Kufi)", en:"Reem Kufi" },
  { key:"Amiri", ar:"عربي كلاسيكي (Amiri)", en:"Amiri" },
  { key:"Mirza", ar:"ديواني بديل (Mirza)", en:"Mirza" },
  { key:"Rakkas", ar:"ديواني مزخرف (Rakkas)", en:"Rakkas" },
  { key:"Inter", ar:"إنجليزي (Inter)", en:"Inter" }
];

const pages = ["home","templates","editor","checkout","admin","pricing"];
function showPage(p){
  pages.forEach(x => $(`page-${x}`).classList.add("hidden"));
  $(`page-${p}`).classList.remove("hidden");
  window.scrollTo({ top:0, behavior:"smooth" });
  location.hash = p;
}

function toast(el, msg, err=false){
  el.innerHTML = `<div class="toast ${err?'err':''}">${msg}</div>`;
}
function clamp(n,a,b){ return Math.max(a, Math.min(b,n)); }
function fileToDataUrl(file){
  return new Promise((resolve,reject)=>{
    const r = new FileReader();
    r.onload = ()=> resolve(String(r.result));
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

// Local templates storage (MVP)
const LS_KEY = "sg_templates_v1";
function saveTemplates(){ localStorage.setItem(LS_KEY, JSON.stringify(state.templates)); }
function loadTemplates(){
  const raw = localStorage.getItem(LS_KEY);
  if (raw){
    try{ state.templates = JSON.parse(raw) || []; } catch { state.templates = []; }
  }
  if (!state.templates.length){
    state.templates = [{
      id:"tpl_default",
      name:"Modern Corporate",
      price:5,
      maxSlides:10,
      bgDataUrl:"https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1400&q=60",
      titleBox:{x:7,y:10,w:60,h:18},
      bodyBox:{x:7,y:32,w:60,h:52},
      imageBox:{x:70,y:14,w:24,h:70}
    }];
    saveTemplates();
  }
}

function applyLang(){
  const lang = state.lang;
  document.documentElement.lang = lang;
  document.documentElement.dir = (lang==="ar") ? "rtl" : "ltr";

  $("brandSub").textContent = T[lang].brandSub;
  $("navHome").textContent = T[lang].navHome;
  $("navTemplates").textContent = T[lang].navTemplates;
  $("navEditor").textContent = T[lang].navEditor;
  $("navPricing").textContent = T[lang].navPricing;
  if ($("navAdmin")) $("navAdmin").textContent = T[lang].navAdmin;

  $("heroTitle").textContent = T[lang].heroTitle;
  $("heroSub").textContent = T[lang].heroSub;

  $("tplTitle").textContent = T[lang].tplTitle;
  $("tplSub").textContent = T[lang].tplSub;

  $("edTitle").textContent = T[lang].edTitle;
  $("edSub").textContent = T[lang].edSub;
  $("settingsTitle").textContent = T[lang].settingsTitle;

  $("lblTemplate").textContent = T[lang].lblTemplate;
  $("lblTopic").textContent = T[lang].lblTopic;
  $("lblBody").textContent = T[lang].lblBody;
  $("lblFont").textContent = T[lang].lblFont;
  $("lblFontSize").textContent = T[lang].lblFontSize;
  $("lblColor").textContent = T[lang].lblColor;
  $("lblSlides").textContent = T[lang].lblSlides;
  $("lblUserImage").textContent = T[lang].lblUserImage;

  $("previewTitle").textContent = T[lang].previewTitle;
  $("previewHint").textContent = T[lang].previewHint;

  $("ckTitle").textContent = T[lang].ckTitle;
  $("ckSub").textContent = T[lang].ckSub;
  $("orderTitle").textContent = T[lang].orderTitle;
  $("ppBoxTitle").textContent = T[lang].ppBoxTitle;
  $("ppNote").textContent = T[lang].ppNote;

  $("adTitle").textContent = T[lang].adTitle;
  $("adSub").textContent = T[lang].adSub;
  $("tplAddTitle").textContent = T[lang].tplAddTitle;
  $("lblTplName").textContent = T[lang].lblTplName;
  $("lblTplPrice").textContent = T[lang].lblTplPrice;
  $("lblTplMax").textContent = T[lang].lblTplMax;
  $("lblTplBg").textContent = T[lang].lblTplBg;
  $("tplListTitle").textContent = T[lang].tplListTitle;
  $("adminPreviewTitle").textContent = T[lang].adminPreviewTitle;

  $("prTitle").textContent = T[lang].prTitle;
  $("prSub").textContent = T[lang].prSub;

  $("toggleLang").textContent = (lang==="ar") ? "EN" : "AR";
}

function renderFontSelect(){
  const sel = $("selFont");
  sel.innerHTML = "";
  fonts.forEach(f=>{
    const opt = document.createElement("option");
    opt.value = f.key;
    opt.textContent = (state.lang==="ar") ? f.ar : f.en;
    sel.appendChild(opt);
  });
  sel.value = state.editor.font;
}

function syncEditorTemplateSelect(){
  const sel = $("selTemplate");
  sel.innerHTML = "";
  state.templates.forEach(t=>{
    const opt = document.createElement("option");
    opt.value = t.id;
    opt.textContent = `${t.name} ($${t.price})`;
    sel.appendChild(opt);
  });
  if (!state.editor.templateId) state.editor.templateId = state.templates[0]?.id || "";
  sel.value = state.editor.templateId;
}

function getTpl(){
  return state.templates.find(t=>t.id===state.editor.templateId) || state.templates[0];
}

function renderTemplatesGrid(){
  const grid = $("templatesGrid");
  grid.innerHTML = "";
  state.templates.forEach(t=>{
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div style="font-weight:900">${t.name}</div>
      <div class="mini" style="margin-top:6px">$${t.price} • max ${t.maxSlides} slides</div>
      <div class="previewStage" style="margin-top:10px">
        <div class="previewBg" style="background-image:url('${t.bgDataUrl}')"></div>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <button class="btn">Use</button>
      </div>
    `;
    card.querySelector("button").addEventListener("click", ()=>{
      state.editor.templateId = t.id;
      syncEditorTemplateSelect();
      showPage("editor");
      renderPreview();
    });
    grid.appendChild(card);
  });
}

function renderAdminList(){
  const list = $("adminList");
  list.innerHTML = "";
  state.templates.forEach(t=>{
    const row = document.createElement("div");
    row.className = "card";
    row.style.marginBottom = "10px";
    row.innerHTML = `
      <div class="rowBetween">
        <div>
          <div style="font-weight:900">${t.name}</div>
          <div class="mini">$${t.price} • max ${t.maxSlides} • ${t.id}</div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn2" data-use>Use</button>
          <button class="btn2" data-del>Delete</button>
        </div>
      </div>
    `;
    row.querySelector("[data-use]").addEventListener("click", ()=>{
      state.editor.templateId = t.id;
      syncEditorTemplateSelect();
      showPage("editor");
      renderPreview();
    });
    row.querySelector("[data-del]").addEventListener("click", ()=>{
      state.templates = state.templates.filter(x=>x.id!==t.id);
      saveTemplates();
      syncEditorTemplateSelect();
      renderTemplatesGrid();
      renderAdminList();
      toast($("adminTplMsg"), (state.lang==="ar" ? "✅ تم حذف القالب" : "✅ Template deleted"));
    });
    list.appendChild(row);
  });
}

function applyBox(el, box){
  el.style.left = box.x + "%";
  el.style.top = box.y + "%";
  el.style.width = box.w + "%";
  el.style.height = box.h + "%";
}
function renderPreview(){
  const tpl = getTpl();
  if (!tpl) return;

  document.documentElement.style.setProperty("--brand", state.editor.color);

  $("stageBg").style.backgroundImage = `url('${tpl.bgDataUrl}')`;
  applyBox($("boxTitle"), tpl.titleBox);
  applyBox($("boxBody"), tpl.bodyBox);
  applyBox($("boxImage"), tpl.imageBox);

  const titleEl = $("renderTitle");
  const bodyEl  = $("renderBody");
  const imgEl   = $("renderImage");

  titleEl.style.left = tpl.titleBox.x + "%";
  titleEl.style.top  = tpl.titleBox.y + "%";
  titleEl.style.width= tpl.titleBox.w + "%";
  titleEl.style.height=tpl.titleBox.h + "%";

  bodyEl.style.left = tpl.bodyBox.x + "%";
  bodyEl.style.top  = tpl.bodyBox.y + "%";
  bodyEl.style.width= tpl.bodyBox.w + "%";
  bodyEl.style.height=tpl.bodyBox.h + "%";

  imgEl.style.left = tpl.imageBox.x + "%";
  imgEl.style.top  = tpl.imageBox.y + "%";
  imgEl.style.width= tpl.imageBox.w + "%";
  imgEl.style.height=tpl.imageBox.h + "%";

  titleEl.style.fontFamily = state.editor.font;
  bodyEl.style.fontFamily  = state.editor.font;

  titleEl.style.fontSize = (Number(state.editor.fontSize) + 10) + "px";
  bodyEl.style.fontSize  = Number(state.editor.fontSize) + "px";

  titleEl.textContent = state.editor.title || (state.lang==="ar" ? "عنوان العرض" : "Deck Title");
  bodyEl.textContent  = state.editor.body  || (state.lang==="ar" ? "اكتب المحتوى هنا..." : "Write content here...");

  if (state.editor.userImageDataUrl){
    imgEl.src = state.editor.userImageDataUrl;
    imgEl.style.display = "block";
  } else {
    imgEl.style.display = "none";
  }
}

// Admin drag
function makeDraggable(boxEl, getBox, setBox){
  let dragging = false;
  let start = null;
  const stage = $("adminStage");

  function posToPercent(clientX, clientY){
    const rect = stage.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 100;
    const y = ((clientY - rect.top)  / rect.height)* 100;
    return { x, y, rect };
  }

  const down = (e)=>{
    if (!state.boxEditMode) return;
    dragging = true;
    const touch = e.touches ? e.touches[0] : e;
    const cur = posToPercent(touch.clientX, touch.clientY);
    const b = getBox();
    start = { cur, b: { ...b } };
    e.preventDefault();
  };

  const move = (e)=>{
    if (!dragging || !state.boxEditMode) return;
    const touch = e.touches ? e.touches[0] : e;
    const cur = posToPercent(touch.clientX, touch.clientY);
    const dx = cur.x - start.cur.x;
    const dy = cur.y - start.cur.y;

    const b = { ...start.b };
    b.x = clamp(b.x + dx, 0, 100 - b.w);
    b.y = clamp(b.y + dy, 0, 100 - b.h);

    setBox(b);
    applyBox(boxEl, b);
    e.preventDefault();
  };

  const up = ()=>{ dragging = false; start = null; };

  boxEl.addEventListener("touchstart", down, { passive:false });
  boxEl.addEventListener("touchmove",  move, { passive:false });
  boxEl.addEventListener("touchend",   up);
  boxEl.addEventListener("mousedown", down);
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}

function updateAdminStage(){
  $("adminStageBg").style.backgroundImage = state.adminDraft.bgDataUrl ? `url('${state.adminDraft.bgDataUrl}')` : "none";
  applyBox($("adminBoxTitle"), state.adminDraft.titleBox);
  applyBox($("adminBoxBody"),  state.adminDraft.bodyBox);
  applyBox($("adminBoxImage"), state.adminDraft.imageBox);
}

async function saveTemplate(){
  const name = $("inpTplName").value.trim();
  const price = Number($("inpTplPrice").value || 0);
  const maxSlides = Number($("inpTplMax").value || 10);

  if (!name || !price){
    toast($("adminTplMsg"), state.lang==="ar" ? "❌ الاسم والسعر مطلوبين" : "❌ Name & price required", true);
    return;
  }
  if (!state.adminDraft.bgDataUrl){
    toast($("adminTplMsg"), state.lang==="ar" ? "❌ ارفعي صورة خلفية للقالب" : "❌ Upload background image", true);
    return;
  }

  const tpl = {
    id: "tpl_" + Math.random().toString(16).slice(2),
    name, price, maxSlides,
    bgDataUrl: state.adminDraft.bgDataUrl,
    titleBox: { ...state.adminDraft.titleBox },
    bodyBox:  { ...state.adminDraft.bodyBox },
    imageBox: { ...state.adminDraft.imageBox }
  };

  state.templates.unshift(tpl);
  saveTemplates();
  syncEditorTemplateSelect();
  renderTemplatesGrid();
  renderAdminList();
  toast($("adminTplMsg"), state.lang==="ar" ? "✅ تم حفظ القالب" : "✅ Template saved");
}

// PayPal
let paypalSdkPromise = null;
function loadPayPalSdk(){
  if (window.paypal) return Promise.resolve();
  if (!PAYPAL_CLIENT_ID){
    return Promise.reject(new Error("PayPal Client ID missing"));
  }
  if (!paypalSdkPromise){
    paypalSdkPromise = new Promise((resolve, reject)=>{
      const s = document.createElement("script");
      s.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(PAYPAL_CLIENT_ID)}&currency=${encodeURIComponent(CURRENCY)}&intent=capture`;
      s.onload = ()=> resolve();
      s.onerror = ()=> reject(new Error("Failed to load PayPal SDK"));
      document.head.appendChild(s);
    });
  }
  return paypalSdkPromise;
}

async function renderPayPalButtons(){
  const box = $("paypalBtnContainer");
  box.innerHTML = "";

  try{
    await loadPayPalSdk();
  }catch(e){
    toast($("checkoutMsg"),
      (state.lang==="ar"
        ? "❌ ما ظهر زر PayPal لأن PAYPAL_CLIENT_ID غير موجود.
ضعيه في إعدادات الاستضافة (ENV: PAYPAL_CLIENT_ID)."
        : "❌ PayPal button not shown: missing PAYPAL_CLIENT_ID.
Set ENV: PAYPAL_CLIENT_ID."),
      true
    );
    return;
  }

  const tpl = getTpl();
  const amount = calcPriceUSD(tpl.price, state.editor.slides);

  $("checkoutMsg").innerHTML = "";
  window.paypal.Buttons({
    style: { layout: "vertical", label: "paypal" },
    createOrder: (data, actions) => actions.order.create({
      purchase_units: [{
        description: `SlideGenius deck - ${tpl.name}`,
        amount: { value: amount.toFixed(2) }
      }]
    }),
    onApprove: (data, actions) => actions.order.capture().then((details)=>{
      const name = details?.payer?.name?.given_name || "";
      toast($("checkoutMsg"),
        (state.lang==="ar" ? `✅ تم الدفع بنجاح!\nشكرًا ${name}` : `✅ Payment successful!\nThanks ${name}`)
      );
    }),
    onError: (err) => toast($("checkoutMsg"),
      (state.lang==="ar" ? `❌ خطأ PayPal:\n${err?.message || String(err)}` : `❌ PayPal error:\n${err?.message || String(err)}`),
      true
    )
  }).render("#paypalBtnContainer");
}

function renderOrderDetails(){
  const tpl = getTpl();
  const slides = Number(state.editor.slides);
  const amount = calcPriceUSD(tpl.price, slides);
  $("orderDetails").textContent =
    (state.lang==="ar")
      ? `القالب: ${tpl.name}\nعدد الشرائح: ${slides}\nالعملة: ${CURRENCY}\nالسعر النهائي: $${amount}`
      : `Template: ${tpl.name}\nSlides: ${slides}\nCurrency: ${CURRENCY}\nFinal: $${amount}`;
}

async function fetchMe(){
  try{
    const r = await fetch("/api/me", { credentials: "include" });
    const j = await r.json();
    state.isAdmin = !!j.isAdmin;
  } catch {
    state.isAdmin = false;
  }
  const navAdmin = $("navAdmin");
  if (navAdmin){
    if (state.isAdmin) navAdmin.classList.remove("hidden");
    else navAdmin.classList.add("hidden");
  }
}

function wire(){
  $("navHome").onclick = ()=> showPage("home");
  $("navTemplates").onclick = ()=> { showPage("templates"); renderTemplatesGrid(); };
  $("navEditor").onclick = ()=> { showPage("editor"); renderPreview(); };
  $("navPricing").onclick = ()=> showPage("pricing");
  if ($("navAdmin")){
    $("navAdmin").onclick = ()=> { showPage("admin"); updateAdminStage(); renderAdminList(); };
  }

  $("btnGoEditor").onclick = ()=> { showPage("editor"); renderPreview(); };
  $("btnGoTemplates").onclick = ()=> { showPage("templates"); renderTemplatesGrid(); };

  $("btnBackHomeFromTemplates").onclick = ()=> showPage("home");
  $("btnBackHomeFromEditor").onclick = ()=> showPage("home");
  $("btnBackHomeFromAdmin").onclick = ()=> showPage("home");
  $("btnBackHomeFromPricing").onclick = ()=> showPage("home");
  $("btnBackToEditor").onclick = ()=> showPage("editor");

  $("toggleLang").onclick = ()=>{
    state.lang = (state.lang==="ar") ? "en" : "ar";
    applyLang();
    renderFontSelect();
    renderTemplatesGrid();
    syncEditorTemplateSelect();
    renderPreview();
  };

  $("selTemplate").onchange = (e)=>{ state.editor.templateId = e.target.value; renderPreview(); };
  $("inpTitle").oninput = (e)=>{ state.editor.title = e.target.value; };
  $("inpBody").oninput  = (e)=>{ state.editor.body = e.target.value; };
  $("selFont").onchange = (e)=>{ state.editor.font = e.target.value; renderPreview(); };
  $("selFontSize").onchange = (e)=>{ state.editor.fontSize = Number(e.target.value); renderPreview(); };
  $("inpColor").oninput = (e)=>{ state.editor.color = e.target.value; renderPreview(); };
  $("selSlides").onchange = (e)=>{ state.editor.slides = Number(e.target.value); };

  $("inpUserImage").addEventListener("change", async (e)=>{
    const f = e.target.files?.[0];
    if (!f) return;
    state.editor.userImageDataUrl = await fileToDataUrl(f);
    renderPreview();
    toast($("editorMsg"), state.lang==="ar" ? "✅ تم رفع الصورة" : "✅ Image uploaded");
  });

  $("btnPreview").onclick = ()=>{ renderPreview(); toast($("editorMsg"), state.lang==="ar" ? "✅ تم تحديث المعاينة" : "✅ Preview updated"); };

  $("btnGoCheckout").onclick = async ()=>{
    showPage("checkout");
    renderOrderDetails();
    await renderPayPalButtons();
  };

  $("btnBoxMode").onclick = ()=>{
    state.boxEditMode = !state.boxEditMode;
    toast($("adminTplMsg"),
      state.boxEditMode
        ? (state.lang==="ar" ? "✅ وضع تحريك الصناديق: شغال (اسحبي المربعات)" : "✅ Box move mode: ON")
        : (state.lang==="ar" ? "تم إيقاف وضع التحريك" : "Box move mode: OFF")
    );
  };

  $("inpTplBg").addEventListener("change", async (e)=>{
    const f = e.target.files?.[0];
    if (!f) return;
    state.adminDraft.bgDataUrl = await fileToDataUrl(f);
    updateAdminStage();
    toast($("adminTplMsg"), state.lang==="ar" ? "✅ تم رفع خلفية القالب" : "✅ Background uploaded");
  });

  $("btnSaveTpl").onclick = (e)=>{ e.preventDefault(); saveTemplate(); };

  $("pricingNote").textContent = (state.lang==="ar")
    ? "اختاري قالب من المحرر وشوفي السعر النهائي في صفحة الدفع."
    : "Pick a template in Editor and see final price in Checkout.";
}

function initDrag(){
  makeDraggable($("adminBoxTitle"), ()=>state.adminDraft.titleBox, (b)=>state.adminDraft.titleBox=b);
  makeDraggable($("adminBoxBody"),  ()=>state.adminDraft.bodyBox,  (b)=>state.adminDraft.bodyBox=b);
  makeDraggable($("adminBoxImage"), ()=>state.adminDraft.imageBox, (b)=>state.adminDraft.imageBox=b);
}

async function init(){
  loadTemplates();
  await fetchMe();
  applyLang();
  renderFontSelect();
  syncEditorTemplateSelect();
  renderTemplatesGrid();
  renderAdminList();
  updateAdminStage();
  renderPreview();
  wire();
  initDrag();

  const h = (location.hash || "#home").replace("#","");
  if (pages.includes(h)) showPage(h); else showPage("home");

  // If backend opened admin route, go there
  if (window.__OPEN_ADMIN__ && state.isAdmin){
    showPage("admin");
  }
}

init();
