# SlideGenius (Launch MVP) — Admin Protected ✅

## كلمة مرور الأدمن (مؤقتًا)
**SG!!^Jgp4HB7GB_Oe01BV**
> تقدرين تغيرينها بسهولة من ENV: `ADMIN_PASSWORD` بعد النشر.

## كيف تشغليه محليًا (اختياري)
1) افتحي مجلد `backend`
2) `npm install`
3) (اختياري) انسخي `.env.example` إلى `.env`
4) `npm start`
ثم افتحي: http://localhost:8787

## النشر على Render (أسهل على الآيباد)
### 1) ارفعي المشروع على GitHub
- افتحي GitHub من المتصفح
- New repository
- Upload files
- ارفعي محتويات المجلد `slidegenius_launch`

### 2) Render
- New + -> Web Service
- اختاري الريبو
- Root directory: `backend`
- Build command: `npm install`
- Start command: `npm start`

### 3) Environment Variables (مهم)
في Render -> Environment:
- `ADMIN_PASSWORD` = **SG!!^Jgp4HB7GB_Oe01BV**
- `SESSION_SECRET` = (أي نص طويل، مثال: `sg_session_SG!!^Jgp4HB7GB_Oe01BV`)
- `PAYPAL_CLIENT_ID` = (Client ID حق PayPal Sandbox أو Live)

## دخول الأدمن
بعد ما يشتغل الموقع:
- افتحي: `https://YOUR-SITE.onrender.com/admin`
- بيطلع لك صفحة كلمة المرور
- بعد الدخول بتظهر لك صفحة الأدمن داخل الموقع
